package projects.hugo.excepitions;

public class ViaCepFormatException extends RuntimeException {
    public ViaCepFormatException(String s) {
        super(s);
    }
}
