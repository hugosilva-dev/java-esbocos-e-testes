package projects.hugo.excepitions;

public class ViaCepException extends RuntimeException {
    public ViaCepException(String s) {
        super(s);
    }
}
